# 三角洲行动手游中国版市场行情助手

Android 原生工程初始框架。

- 平台：Android APK
- 刷新方式：手动刷新
- 目标范围：全部可交易物品
- 数据来源：待确认可用且获准使用的第三方 API

## 当前状态
这是可继续开发的工程骨架，不包含真实行情数据，也不应将演示占位内容视为市场价格。接入数据源前，刷新按钮只会提示数据源未配置。

## 构建
使用 Android Gradle Plugin 8.7.3、Gradle 8.9、JDK 17，执行：

`gradle assembleDebug`

生成文件：`app/build/outputs/apk/debug/app-debug.apk`
